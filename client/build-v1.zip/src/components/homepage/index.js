import React, { useState, useEffect, useRef } from 'react'
import { StockWidget } from '../stock/widget';
import { fetchHome } from '../../api';

function Homepage() {
    const [homeStocks, setHomeStocks] = useState(null);

    useEffect(() => {
        (async () => {
            const d = await fetchHome();
            if (!d.pass) return;
            setHomeStocks(d.data);
        })();
    }, []);

    return (
        <>
            <button className="page-button">+ Add Stock</button>
            <div style={{ clear: "both" }}></div>
            <div className="row">
                {homeStocks &&
                    homeStocks.map(stock => (<StockWidget stock={stock} key={"stock" + stock.id} />))}
            </div>

            <button className="expand-button">View All</button>

            <h1>Recent News</h1>
            <div className="row">
                <div className="col-lg-4">
                    <div className="article">
                        <h2>Chinese IPOs are coming back to the U.S.</h2>
                        <span>Published Fri, Feb 10 20233:22 AM EST</span>
                        <p>
                            BEIJING — Chinese startups are raising millions of dollars in U.S. stock market listings
                            again,
                            after a dry spell in the once-hot market.

                            Hesai Group, which sells “lidar” tech for self-driving cars, listed on the Nasdaq Thursday.
                            Shares
                            soared nearly 11% in the debut.

                            The company raised $190 million in its initial public offering, more than initial plans —
                            and one of
                            the largest listings since ride-hailing giant Didi raised $4.4 billion in its June 2021 IPO.
                            That
                            listing ran afoul of Chinese regulators, who ordered a cybersecurity review into Didi just
                            days
                            after its public listing. The company delisted later that year.
                        </p>
                        <div><button>Continue Reading <i className="bi bi-box-arrow-up-right"></i></button></div>
                    </div>
                </div>
                <div className="col-lg-4">
                    <div className="article">
                        <h2>10-year Treasury yield rises, traders look ahead to key U.S. inflation data</h2>
                        <span>Published Fri, Feb 10 20234:52 AM EST</span>
                        <p>
                            The 10-year Treasury yield rose Friday as investors looked to economic data and comments
                            from Federal Reserve officials to assess the outlook for inflation and monetary policy.

                            The 10-year Treasury yield was trading at 3.719% after rising by 4 basis points. The yield
                            on the 2-year Treasury was down by under under 1 basis point at 4.5%.

                            Yields and prices move in opposite directions. One basis point equals 0.01%.
                        </p>
                        <div><button>Continue Reading <i className="bi bi-box-arrow-up-right"></i></button></div>
                    </div>
                </div>
                <div className="col-lg-4">
                    <div className="article">
                        <h2>Shell’s board of directors sued over climate strategy in a first-of-its-kind lawsuit</h2>
                        <span>Published Thu, Feb 9 20234:07 AM EST</span>
                        <p>
                            Shell’s directors are being personally sued for allegedly failing to adequately manage the
                            risks associated with the climate emergency in a first-of-its-kind lawsuit that could have
                            widespread implications for how other companies plan to cut emissions.

                            Environmental law firm ClientEarth, in its capacity as a shareholder, filed the lawsuit
                            against the British oil major’s board at the high court of England and Wales on Thursday.
                        </p>
                        <div><button>Continue Reading <i className="bi bi-box-arrow-up-right"></i></button></div>
                    </div>
                </div>
            </div>

            <div className="row">
                <div className="col-lg-4">
                    <div className="article">
                        <h2>BP posts record 2022 earnings to join Big Oil profit bonanza</h2>
                        <span>Published Tue, Feb 7 20232:09 AM EST</span>
                        <p>
                            Analysts polled by Refinitiv had expected net profit of $27.6 billion for full-year 2022. BP
                            said its previous annual profit record was $26.3 billion in 2008.

                            For the fourth quarter, BP posted net profit of $4.8 billion, narrowly beating analyst
                            expectations of $4.7 billion.

                            BP announced a further $2.75 billion share buyback, which it expects to complete prior to
                            announcing its first-quarter 2023 results in early May. It also boosted its dividend by 10%
                            to 6.61 cents per ordinary share.
                        </p>
                        <div><button>Continue Reading <i className="bi bi-box-arrow-up-right"></i></button></div>
                    </div>
                </div>
                <div className="col-lg-4">
                    <div className="article">
                        <h2>There isn’t enough copper in the world — and the shortage could last till 2030</h2>
                        <span>Published Mon, Feb 6 20239:28 PM EST</span>
                        <p>
                            A copper deficit is set to inundate global markets throughout 2023 — and one analyst
                            predicts the shortfall could potentially extend throughout the rest of the decade.

                            The world is currently facing a global copper shortage, fueled by increasingly challenging
                            supply streams in South America and higher demand pressures.

                            Copper is a leading pulse check for economic health due to its incorporation in various uses
                            such as electrical equipment and industrial machinery.

                            A copper squeeze could be an indicator that global inflationary pressures will worsen, and
                            subsequently compel central banks to maintain their hawkish stance for longer.
                        </p>
                        <div><button>Continue Reading <i className="bi bi-box-arrow-up-right"></i></button></div>
                    </div>
                </div>
                <div className="col-lg-4">
                    <div className="article">
                        <h2>European markets close lower as investors assess monetary policy outlook; Stoxx 600 down 1%
                        </h2>
                        <span>Published Mon, Feb 6 20239:28 PM EST</span>
                        <p>
                            European markets closed lower Friday as investors assess the economic outlook and the
                            potential for further monetary policy tightening from the U.S. Federal Reserve.

                            The pan-European Stoxx 600 index finished trading down 1%. Most sectors and major bourses
                            closed in the red, with travel and leisure stocks leading losses, down by 3.8%. Oil and gas
                            stocks bucked the trend with a 2.3% uptick, while telecoms stocks were 0.2% higher.

                            The index closed higher on Thursday with the economic outlook and corporate earnings high on
                            the agenda.
                        </p>
                        <div><button>Continue Reading <i className="bi bi-box-arrow-up-right"></i></button></div>
                    </div>
                </div>
            </div>
        </>
    );
}

export default Homepage;
